<?php include "db.php"; ?>
<?php session_start(); ?>



<?php 

if (isset($_POST['login'])) {
	
	 $username = $_POST['username'];
	 $password = $_POST['password']; ;

	 $username = mysqli_real_escape_string($connection,$username);
	 $password = mysqli_real_escape_string($connection,$password);

	 //$hash = password_hash($password, PASSWORD_BCRYPT);
                
       //         $password = $hash;

$query = "SELECT * FROM users WHERE username = '{$username}' ";

$select_user_query = mysqli_query($connection, $query);

if(mysqli_num_rows($select_user_query) > 0)  
           {  
                while($row = mysqli_fetch_array($select_user_query))  
                {  
                     if(password_verify($password, $row["user_password"]))  
                     {  
                          //return true;  
                          $_SESSION["username"] = $username; 

                          header("Location: ../admin");  
                     }  





}


}  
           else  
                     {  
                          //return false;  
                         header("Location: ../index.php");
                     }  
                }  
    
           else  
           {  
                echo '<script>alert("Wrong User Details")</script>';  
           }  
        


?>







<?php


if(mysqli_num_rows($result) > 0)  
           {  
                while($row = mysqli_fetch_array($result))  
                {  
                     if(password_verify($password, $row["password"]))  
                     {  
                          //return true;  
                          $_SESSION["username"] = $username;  
                          header("location: ../admin.php");  
                     }  
                     else  
                     {  
                          //return false;  
                          echo '<script>alert("Wrong User Details")</script>';  
                     }  
                }  
           }  
           else  
           {  
                echo '<script>alert("Wrong User Details")</script>';  
           }  
        
   


?>









