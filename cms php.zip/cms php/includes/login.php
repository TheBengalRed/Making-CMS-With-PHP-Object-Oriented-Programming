<?php include "db.php"; ?>
<?php session_start(); ?>



<?php 

if (isset($_POST['login'])) {
	
	 $username = $_POST['username'];
	 $password = $_POST['password']; ;

	 $username = mysqli_real_escape_string($connection,$username);
	 $password = mysqli_real_escape_string($connection,$password); 

$query = "SELECT * FROM users WHERE username = '{$username}' ";

$select_user_query = mysqli_query($connection, $query);

$select_user_query_check = mysqli_num_rows($select_user_query);


if ($select_user_query_check < 1) {

	header("Location: ../index.php" );
} else{

		  if ($row = mysqli_fetch_assoc($select_user_query)) {
	$hashed_password_check = password_verify($password, $row['user_password']);

	if ($hashed_password_check == false) {

		header("Location: ../index.php" );
	} elseif ($hashed_password_check == true) {

	$_SESSION['user_id'] = $row['user_id'];
	$_SESSION['password'] = $row['user_password'];
	$_SESSION['username'] = $row['username'];
	$_SESSION['firstname'] = $row['user_firstname'];
	$_SESSION['lastname'] = $row['user_lastname'];
	$_SESSION['user_role'] = $row['user_role'];

	header('Location: ../admin');
	}
		  }
}


// 	$password = $password;
// 	$db_hash_password = password_hash($password, PASSWORD_DEFAULT);

// 	password_verify($password, $db_hash_password);


// if (!$select_user_query) {

// 	die("USER LOGIN FAIL" . mysqli_error($connection));

// } 


// // while ($row = mysqli_fetch_array($select_user_query)) {
// // 	 $db_user_id = $row['user_id'];

// // 	 $db_username = $row['username'];
// // 	$db_user_password = $row['user_password'];
// // 	$db_user_firstname = $row['user_firstname'];
// // 	 $db_user_lastname = $row['user_lastname'];
// // 	$db_user_role = $row['user_role'];


// // }



// if ($username === $db_username && $password === $db_password) {


// 	$_SESSION['username'] = $db_username;
// 	$_SESSION['firstname'] = $db_user_firstname;
// 	$_SESSION['lastname'] = $db_user_lastname;
// 	$_SESSION['user_role'] = $db_user_role;

// 	//header("Location: ../admin" );
// 	header('Location: ../admin');

// }else {
// 	header("Location: ../index.php" );

// }





}else {
	header("Location: ../index.php" );
 }


?>