 <div class="col-md-4">











                <!-- Login -->
                <div class="well">
                    <h4>Login</h4>
                   
                   <form action="includes/login.php" method="post">
                   	
<div class="form-group">
<input name="username" type="text" class="form-control" placeholder="Enter Username">
</div>



<div class="input-group">
    <input name="password" type="password" class="form-control" placeholder="Enter Password">
    
<span class="input-group-btn">

<button class="btn btn-primary" name="login" type="submit"> Submit </button>

 </span>

 </div>
                   </form>


                    <!-- /.input-group -->
                </div>




                <!-- Blog Categories Well -->



                	<?php


						$query = "SELECT * FROM categories";

                		$show_all_data = mysqli_query($connection,$query);
						
						
						
						 ?>





                <div class="well">
                    <h4>Blog Categories</h4>
                    <div class="row">
                        <div class="col-6">
                            <ul class="list-unstyled" style="margin-left:15px;">

                            		<?php 


                            			while($row = mysqli_fetch_assoc($show_all_data)) {


								


                				$cat_name = $row['cat_name'];
                                $cat_id = $row['cat_id'];

     							echo "<li> <a href='category.php?category=$cat_id'>" .$cat_name. "</a> </li>";

		                	}



                            		?>




                                
                            </ul>
                        </div>
                      
                        <!-- /.col-lg-6 -->
                    </div>
                    <!-- /.row -->
                </div>

                <!-- Side Widget Well -->
                <div class="well">
                    
                		<?php include "widget.php"; ?>


                </div>

            </div>
