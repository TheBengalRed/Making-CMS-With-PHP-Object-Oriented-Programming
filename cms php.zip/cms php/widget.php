<h3> <p class="card-text btn btn-info btn-block">Dont Have An Account? Please <a href="registration.php">Registration</a> .</p>
  




<!-- 
<h4>Don't Have An Account?</h4>
                    


<a href="registration.php" style="text-decoration: none;"> 
                                  
                                  <p class="card-text btn btn-info btn-block" style="color:white;"> 
                                                                                                  
                                                                                                  
                                                                                                  
                                   Please Register.</p> 
                                                                                               
</a> -->