<?php 


        function escape($string){

            global $connection;

            return mysqli_real_escape_string($connection, trim(strip_tags($string)));

                                }











            function insert_categories() {

            global $connection;

                    if(isset($_POST['submit'])) {
                    $cat_name = $_POST['cat_name'];





                    if($cat_name == "" || empty($cat_name)) {

                    echo "You Need To Type Something";

                    } else{

                    $query = "INSERT INTO categories(cat_name) ";
                    $query .= "VALUE('{$cat_name}') ";

                    $creat_category_query = mysqli_query($connection, $query);


                    if (!$creat_category_query) {
                    die('QUERY FAIL'. mysqli_error($connection));
                    }

                    }




                    }




            }




function find_all_category(){

global $connection;


                    $query = "SELECT * FROM categories";
                    $show_all_category = mysqli_query($connection,$query);
                    while($row = mysqli_fetch_assoc($show_all_category)) {

                    $cat_name = $row['cat_name'];
                    $cat_id = $row['cat_id'];


                    echo "<tr>";
                    echo "<td>{$cat_id}</td>";
                    echo "<td>{$cat_name}</td>";
                    echo "<td><a href='categories.php?delete={$cat_id}'> Delete </a> </td>";
                    echo "<td><a href='categories.php?edit={$cat_id}'> Edit </a> </td>";
                    echo "</tr>";
                    }




}



function delete_category() {
global $connection;


                    if (isset($_GET['delete'])) {

                    $the_cat_id = $_GET['delete'];

                    $query = "DELETE FROM categories WHERE cat_id = {$the_cat_id} ";

                    $delete_query = mysqli_query($connection ,$query);

                    header("Location: categories.php");



                    }






}




function confirm($result) {
    global $connection;


    if (!$result) {
        
        die("NOT OK" . mysqli_error($connection));



    }




}





                        ?>