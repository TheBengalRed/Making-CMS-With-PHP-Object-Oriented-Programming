<?php 

	if (isset($_POST['creat_user'])) {

	 //$user_id = $_POST['user_id'];
	 $user_firstname = $_POST['user_firstname'];
	 $user_lastname = $_POST['user_lastname'];
	 $username = $_POST['username'];
	 $user_role = 'subscriber';


	 //$post_image = $_FILES['post_image']['name'];
	 //$post_image_temp = $_FILES['post_image']['tmp_name'];


	 $user_email = $_POST['user_email'];
	 $user_password = $_POST['user_password'];
	 //$post_date = date('d-y-m');
	 // $post_comment_count = 4;


	 //move_uploaded_file($post_image_temp, "../images/$post_image");




	 $query = "INSERT INTO users(user_firstname, user_lastname, username, user_role, user_email, user_password) ";

	$query .= "VALUES('{$user_firstname}','{$user_firstname}','{$username}','{$user_role}','{$user_email}','{$user_password}' ) ";





	$creat_query_for_users = mysqli_query($connection, $query);

	confirm($creat_query_for_users);

	echo "User Created : " . "<a href='users.php'> View Users </a>";


	
	}

?>





 <form action="" method="post" enctype="multipart/form-data">




 	<div class="form-group">

 			<label for="user_firstname" > First Name </label>
 			<input type="text" class="form-control" name="user_firstname">


 	 </div>



 	 <div class="form-group">

 			<label for="user_lastname" > Last Name</label>
 			<input type="text" class="form-control" name="user_lastname">


 	 </div>




 <div class="form-group">

 			<label for="username" > Username </label>
 			<input type="text" class="form-control" name="username">


 	 </div>




 <div class="form-group">

 			
 			<select name="user_role" id=""> 

 					<option value="subscriber"> Select Your Option</option>
 					<option value="admin">Admin</option>
 					<option value="subscriber">Subscriber</option>




 			</select>


 	 </div>

 	 







 <div class="form-group">

 			<label for="user_email" > Email </label>
 			<input type="email" class="form-control" name="user_email">


 	 </div>



 	 <div class="form-group">

 			<label for="user_password" > Password </label>
 			<input type="text" class="form-control" name="user_password">


 	 </div>



<div class="form-group">

 			<input class="btn btn-primary" type="submit" name="creat_user" value="Add User">


 	 </div>

  </form>	